# Virtual Pet-1
INSTRUCTIONS:
___________________________________________________________________________________
Goal of the Project:
In Class 34 you learned how to create a remote real-time database, how to read and write
and connect to a remote real-time database.
In this project you will have to apply what you have learnt in the class and create a virtual
pet app.
Story:
Shreya really wants a pet. But nobody else in her family wants to bring a pet in the home.
They believe Shreya is not old enough to take care of a pet.
Can you create a virtual pet for Shreya? Create a pet in such a way that Shreya should be
able to take care of it and make sure it does not die.
